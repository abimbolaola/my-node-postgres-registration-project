angular.module('sampleApp', [
  'ngStorage',
  'ui.router'
]);
